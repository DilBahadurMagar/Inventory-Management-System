import { LoginForm } from "@/components/login-form"

export default function Page() {
  return (
    <main className="flex min-h-screen items-center justify-center bg-background p-4">
      <LoginForm />
    </main>
  )
}
